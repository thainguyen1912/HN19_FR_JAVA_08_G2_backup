package fa.training.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="Class_Bath")
public class ClassBath {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "Class_ID")
	private int classId;
	private String className;
	private int plannedTraineeNumber;
	private int acceptedTraineeNumber;
	private int actualTraineeNumber;
	private String status;
	@OneToOne(mappedBy = "classBath")
	private ClassAdmin classAdmin;
	public ClassBath() {
		super();
	}
	public ClassBath(String className, int plannedTraineeNumber, int acceptedTraineeNumber, int actualTraineeNumber,
			String status) {
		super();
		this.className = className;
		this.plannedTraineeNumber = plannedTraineeNumber;
		this.acceptedTraineeNumber = acceptedTraineeNumber;
		this.actualTraineeNumber = actualTraineeNumber;
		this.status = status;
	}
	public int getClassId() {
		return classId;
	}
	public void setClassId(int classId) {
		this.classId = classId;
	}
	public String getClassName() {
		return className;
	}
	public void setClassName(String className) {
		this.className = className;
	}
	public int getPlannedTraineeNumber() {
		return plannedTraineeNumber;
	}
	public void setPlannedTraineeNumber(int plannedTraineeNumber) {
		this.plannedTraineeNumber = plannedTraineeNumber;
	}
	public int getAcceptedTraineeNumber() {
		return acceptedTraineeNumber;
	}
	public void setAcceptedTraineeNumber(int acceptedTraineeNumber) {
		this.acceptedTraineeNumber = acceptedTraineeNumber;
	}
	public int getActualTraineeNumber() {
		return actualTraineeNumber;
	}
	public void setActualTraineeNumber(int actualTraineeNumber) {
		this.actualTraineeNumber = actualTraineeNumber;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public ClassAdmin getClassAdmin() {
		return classAdmin;
	}
	public void setClassAdmin(ClassAdmin classAdmin) {
		this.classAdmin = classAdmin;
	}
	
}
