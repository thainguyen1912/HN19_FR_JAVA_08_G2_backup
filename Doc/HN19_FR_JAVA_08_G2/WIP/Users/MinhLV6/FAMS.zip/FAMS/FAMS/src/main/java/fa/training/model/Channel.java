package fa.training.model;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Channel {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "Channel_ID")
	private int channelId;
	@Column(name = "Channel_Name")
	private String channelName;
	@Column(name="Remarks", nullable = true)
	private String remarks;
	@OneToMany(mappedBy = "candidate")
	private List<Candidate> listCandidate;
	public Channel() {
		super();
	}
	public Channel(String channelName, String remarks) {
		super();
		this.channelName = channelName;
		this.remarks = remarks;
	}
	public int getChannelId() {
		return channelId;
	}
	public void setChannelId(int channelId) {
		this.channelId = channelId;
	}
	public String getChannelName() {
		return channelName;
	}
	public void setChannelName(String channelName) {
		this.channelName = channelName;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public List<Candidate> getListCandidate() {
		return listCandidate;
	}
	public void setListCandidate(List<Candidate> listCandidate) {
		this.listCandidate = listCandidate;
	}
	@Override
	public String toString() {
		return "Channel [channelId=" + channelId + ", channelName=" + channelName + ", remarks=" + remarks + "]";
	}
	
	
}
