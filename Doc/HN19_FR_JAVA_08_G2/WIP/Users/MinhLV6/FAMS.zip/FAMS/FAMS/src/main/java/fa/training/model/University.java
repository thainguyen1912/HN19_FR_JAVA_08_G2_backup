package fa.training.model;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class University {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="University_ID")
	private int universityId;
	@Column(name = "University_Name")
	private String universityName;
	@Column(name = "Remarks", nullable = true)
	private String remarks;
	@OneToMany(mappedBy = "university")
	private List<CandidateProfile> listCandidateProfile;
	public University() {
		super();
	}
	public University(String universityName, String remarks) {
		super();
		this.universityName = universityName;
		this.remarks = remarks;
	}
	
	public int getUniversityId() {
		return universityId;
	}
	public void setUniversityId(int universityId) {
		this.universityId = universityId;
	}
	public String getUniversityName() {
		return universityName;
	}
	public void setUniversityName(String universityName) {
		this.universityName = universityName;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public List<CandidateProfile> getListCandidateProfile() {
		return listCandidateProfile;
	}
	public void setListCandidateProfile(List<CandidateProfile> listCandidateProfile) {
		this.listCandidateProfile = listCandidateProfile;
	}
	@Override
	public String toString() {
		return "University [universityId=" + universityId + ", universityName=" + universityName + ", remarks="
				+ remarks + "]";
	}
	
}
