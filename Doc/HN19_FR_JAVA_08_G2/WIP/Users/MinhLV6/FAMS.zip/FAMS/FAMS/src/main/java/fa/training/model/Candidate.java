package fa.training.model;

import java.time.LocalDate;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

@Entity
public class Candidate {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "Candidate_ID")
	private int candidateID;
	@Column(name = "Application_Date")
	private LocalDate applicationDate;
	@Column(name="Status")
	private String status;
	@Column(name = "History")
	private String history;
	@Column(name = "Remarks")
	private String remarks;
	@OneToMany(mappedBy = "candidate")
	private List<EntryTest> listEntryTest;
	@ManyToOne
	@JoinColumn(name = "Channel_ID", nullable = false)
	private Channel channel;
	@OneToMany(mappedBy = "candidate")
	private List<InterView> listInterview;
	@OneToOne(mappedBy = "candidate")
	private CandidateProfile candidateProfile;
	public Candidate() {
		super();
	}
	public int getCandidateID() {
		return candidateID;
	}
	public void setCandidateID(int candidateID) {
		this.candidateID = candidateID;
	}
	public LocalDate getApplicationDate() {
		return applicationDate;
	}
	public void setApplicationDate(LocalDate applicationDate) {
		this.applicationDate = applicationDate;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getHistory() {
		return history;
	}
	public void setHistory(String history) {
		this.history = history;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	@Override
	public String toString() {
		return "Candidate [candidateID=" + candidateID + ", applicationDate=" + applicationDate + ", status=" + status
				+ ", history=" + history + ", remarks=" + remarks + "]";
	}
	
}
