package fa.training.model;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Faculty {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "Faculty_ID")
	private int facultyId;
	@Column(name = "Faculty_Name")
	private String facultyName;
	@Column(name = "Remarks", nullable = true)
	private String remarks;
	@OneToMany(mappedBy = "faculty")
	private List<CandidateProfile> listCandidateProfile;
	public Faculty() {
		super();
	}
	public int getFacultyId() {
		return facultyId;
	}
	public void setFacultyId(int facultyId) {
		this.facultyId = facultyId;
	}
	public String getFacultyName() {
		return facultyName;
	}
	public void setFacultyName(String facultyName) {
		this.facultyName = facultyName;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public List<CandidateProfile> getListCandidateProfile() {
		return listCandidateProfile;
	}
	public void setListCandidateProfile(List<CandidateProfile> listCandidateProfile) {
		this.listCandidateProfile = listCandidateProfile;
	}
	
}
