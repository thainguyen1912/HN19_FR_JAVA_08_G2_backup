package fa.training.model;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="Candidate_Profile")
public class CandidateProfile {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="Candidate_Profile_ID")
	private int candidateProfileId;
	@Column(name="Full_Name")
	private String fullName;
	@Column(name="DateofBirth")
	private LocalDate dateOfBirth;
	@Column(name="Gender")
	private boolean gender;
	@Column(name="Graduation_Year")
	private int graduationYear;
	@Column(name="Phone",unique = true)
	private int phone;
	@Column(name="Email",unique = true)
	private String email;
	@Column(name="Type")
	private String type;
	@Column(name="Skill")
	private String skill;
	@Column(name="Foreign_Language")
	private String foreignLanguage;
	@Column(name="Level")
	private String level;
	@Column(name="CV")
	private String cv;
	@Column(name="Allocation_Status", nullable = true)
	private String allocationStatus;
	@Column(name="Remarks", nullable = true)
	private String remarks;
	@ManyToOne
	@JoinColumn(name = "University_ID", nullable = false)
	private University university;
	@ManyToOne
	@JoinColumn(name = "Faculty_ID", nullable = false)
	private Faculty faculty;
	@OneToOne
	@JoinColumn(name = "Candidate_ID", nullable = false, unique = true)
	private Candidate candidate;
	public CandidateProfile() {
		super();
	}
	public CandidateProfile(String fullName, LocalDate dateOfBirth, boolean gender, int graduationYear, int phone,
			String email, String type, String skill, String foreignLanguage, String level, String cv,
			String allocationStatus, String remarks, University university, Faculty faculty, Candidate candidate) {
		super();
		this.fullName = fullName;
		this.dateOfBirth = dateOfBirth;
		this.gender = gender;
		this.graduationYear = graduationYear;
		this.phone = phone;
		this.email = email;
		this.type = type;
		this.skill = skill;
		this.foreignLanguage = foreignLanguage;
		this.level = level;
		this.cv = cv;
		this.allocationStatus = allocationStatus;
		this.remarks = remarks;
		this.university = university;
		this.faculty = faculty;
		this.candidate = candidate;
	}
	public int getCandidateProfileId() {
		return candidateProfileId;
	}
	public void setCandidateProfileId(int candidateProfileId) {
		this.candidateProfileId = candidateProfileId;
	}
	public String getFullName() {
		return fullName;
	}
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}
	public LocalDate getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(LocalDate dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public boolean isGender() {
		return gender;
	}
	public void setGender(boolean gender) {
		this.gender = gender;
	}
	public int getGraduationYear() {
		return graduationYear;
	}
	public void setGraduationYear(int graduationYear) {
		this.graduationYear = graduationYear;
	}
	public int getPhone() {
		return phone;
	}
	public void setPhone(int phone) {
		this.phone = phone;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getSkill() {
		return skill;
	}
	public void setSkill(String skill) {
		this.skill = skill;
	}
	public String getForeignLanguage() {
		return foreignLanguage;
	}
	public void setForeignLanguage(String foreignLanguage) {
		this.foreignLanguage = foreignLanguage;
	}
	public String getLevel() {
		return level;
	}
	public void setLevel(String level) {
		this.level = level;
	}
	public String getCv() {
		return cv;
	}
	public void setCv(String cv) {
		this.cv = cv;
	}
	public String getAllocationStatus() {
		return allocationStatus;
	}
	public void setAllocationStatus(String allocationStatus) {
		this.allocationStatus = allocationStatus;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public University getUniversity() {
		return university;
	}
	public void setUniversity(University university) {
		this.university = university;
	}
	public Faculty getFaculty() {
		return faculty;
	}
	public void setFaculty(Faculty faculty) {
		this.faculty = faculty;
	}
	public Candidate getCandidate() {
		return candidate;
	}
	public void setCandidate(Candidate candidate) {
		this.candidate = candidate;
	}
	@Override
	public String toString() {
		return "CandidateProfile [candidateProfileId=" + candidateProfileId + ", fullName=" + fullName
				+ ", dateOfBirth=" + dateOfBirth + ", gender=" + gender + ", graduationYear=" + graduationYear
				+ ", phone=" + phone + ", email=" + email + ", type=" + type + ", skill=" + skill + ", foreignLanguage="
				+ foreignLanguage + ", level=" + level + ", cv=" + cv + ", allocationStatus=" + allocationStatus
				+ ", remarks=" + remarks + "]";
	}
	
}
