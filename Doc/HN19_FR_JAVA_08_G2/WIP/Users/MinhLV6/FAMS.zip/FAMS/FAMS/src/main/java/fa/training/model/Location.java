package fa.training.model;

import javax.persistence.Entity;

@Entity
public class Location {
private int locationId;
private String locationName;
private String remarks;
public Location() {
	super();
}
public int getLocationId() {
	return locationId;
}
public void setLocationId(int locationId) {
	this.locationId = locationId;
}
public String getLocationName() {
	return locationName;
}
public void setLocationName(String locationName) {
	this.locationName = locationName;
}
public String getRemarks() {
	return remarks;
}
public void setRemarks(String remarks) {
	this.remarks = remarks;
}
@Override
public String toString() {
	return "Location [locationId=" + locationId + ", locationName=" + locationName + ", remarks=" + remarks + "]";
}

}
