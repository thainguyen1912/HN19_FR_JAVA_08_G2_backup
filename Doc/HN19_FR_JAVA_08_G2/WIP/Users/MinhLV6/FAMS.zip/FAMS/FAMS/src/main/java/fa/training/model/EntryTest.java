package fa.training.model;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
@Entity
@Table(name = "EntryTest")
public class EntryTest {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "Test_ID")
	private int testId;
	@Column(name = "Time")
	private int time;
	@Column(name = "Date")
	private LocalDate date;
	@Column(name = "Language_Valuator")
	private String languageValuator;
	@Column(name = "Language_Result")
	private int languageResult;
	@Column(name = "Technical_Valuator")
	private String technicalValuator;
	@Column(name = "Teachnical_result")
	private int technicalResult;
	@Column(name = "Result")
	private String result;
	@Column(name = "Remarks")
	private String remarks;
	@ManyToOne
	@JoinColumn(name = "Candidate_ID")
	private Candidate candidate;
	public EntryTest() {
		super();
	}
	public int getTestId() {
		return testId;
	}
	public void setTestId(int testId) {
		this.testId = testId;
	}
	public int getTime() {
		return time;
	}
	public void setTime(int time) {
		this.time = time;
	}
	public LocalDate getDate() {
		return date;
	}
	public void setDate(LocalDate date) {
		this.date = date;
	}
	public String getLanguageValuator() {
		return languageValuator;
	}
	public void setLanguageValuator(String languageValuator) {
		this.languageValuator = languageValuator;
	}
	public int getLanguageResult() {
		return languageResult;
	}
	public void setLanguageResult(int languageResult) {
		this.languageResult = languageResult;
	}
	public String getTechnicalValuator() {
		return technicalValuator;
	}
	public void setTechnicalValuator(String technicalValuator) {
		this.technicalValuator = technicalValuator;
	}
	public int getTechnicalResult() {
		return technicalResult;
	}
	public void setTechnicalResult(int technicalResult) {
		this.technicalResult = technicalResult;
	}
	public String getResult() {
		return result;
	}
	public void setResult(String result) {
		this.result = result;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public Candidate getCandidate() {
		return candidate;
	}
	public void setCandidate(Candidate candidate) {
		this.candidate = candidate;
	}
	
}
