package fa.training.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "Class_Admin")
public class ClassAdmin {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "Class_Admin_ID")
	private int classAdminId;
	@Column(name = "Remarks")
	private String remarks;
	@OneToOne
	@JoinColumn(name = "Class_ID",nullable = false, unique = true)
	private ClassBath classBath;
	public ClassAdmin() {
		super();
	}
	public int getClassAdminId() {
		return classAdminId;
	}
	public void setClassAdminId(int classAdminId) {
		this.classAdminId = classAdminId;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public ClassBath getClassBath() {
		return classBath;
	}
	public void setClassBath(ClassBath classBath) {
		this.classBath = classBath;
	}
	@Override
	public String toString() {
		return "ClassAdmin [classAdminId=" + classAdminId + ", remarks=" + remarks + "]";
	}
	
}
