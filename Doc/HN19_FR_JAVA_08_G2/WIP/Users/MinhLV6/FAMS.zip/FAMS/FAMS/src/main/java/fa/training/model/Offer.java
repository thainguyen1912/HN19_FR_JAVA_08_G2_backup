package fa.training.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
@Entity
public class Offer {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "Offer_ID")
	private int offerId;
	@Column(name="Job_Rank")
	private int jodRank;
	@Column(name="Teachnlogy")
	private String teachnlogy;
	@Column(name="Contract_Type")
	private String contractType;
	@Column(name="Offer_Salary")
	private int offerSalary;
	@Column(name="Remarks", nullable = true)
	private String remarks;
	@OneToOne(mappedBy = "offer")
	private InterView interView;
	public Offer() {
		super();
	}
	public int getOfferId() {
		return offerId;
	}
	public void setOfferId(int offerId) {
		this.offerId = offerId;
	}
	public int getJodRank() {
		return jodRank;
	}
	public void setJodRank(int jodRank) {
		this.jodRank = jodRank;
	}
	public String getTeachnlogy() {
		return teachnlogy;
	}
	public void setTeachnlogy(String teachnlogy) {
		this.teachnlogy = teachnlogy;
	}
	public String getContractType() {
		return contractType;
	}
	public void setContractType(String contractType) {
		this.contractType = contractType;
	}
	public int getOfferSalary() {
		return offerSalary;
	}
	public void setOfferSalary(int offerSalary) {
		this.offerSalary = offerSalary;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	@Override
	public String toString() {
		return "Offer [offerId=" + offerId + ", jodRank=" + jodRank + ", teachnlogy=" + teachnlogy + ", contractType="
				+ contractType + ", offerSalary=" + offerSalary + ", remarks=" + remarks + "]";
	}
	
	
}
