package fa.training.service;

import fa.training.model.User;

public interface UserService {
	boolean createUser(User user);
}
