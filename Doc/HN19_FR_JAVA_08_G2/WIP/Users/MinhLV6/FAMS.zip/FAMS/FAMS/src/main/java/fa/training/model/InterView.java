package fa.training.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
@Entity
public class InterView {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "Interview_ID")
	private int interviewId;
	@Column(name="Interview_Time")
	private int interviewTime;
	@Column(name="Interviewer")
	private String interviewer;
	@Column(name="Commnets")
	private String commnets;
	@Column(name="Remarks")
	private String remarks;
	@Column(name="Result")
	private String result;
	@ManyToOne
	@JoinColumn(name="Candidate_ID")
	private Candidate candidate;
	@OneToOne
	@JoinColumn(name = "Offer_ID")
	private Offer offer;
	public InterView(int interviewTime, String interviewer, String commnets, String remarks, String result,
			Candidate candidate) {
		super();
		this.interviewTime = interviewTime;
		this.interviewer = interviewer;
		this.commnets = commnets;
		this.remarks = remarks;
		this.result = result;
		this.candidate = candidate;
	}
	
	public int getInterviewId() {
		return interviewId;
	}
	public void setInterviewId(int interviewId) {
		this.interviewId = interviewId;
	}
	public int getInterviewTime() {
		return interviewTime;
	}
	public void setInterviewTime(int interviewTime) {
		this.interviewTime = interviewTime;
	}
	public String getInterviewer() {
		return interviewer;
	}
	public void setInterviewer(String interviewer) {
		this.interviewer = interviewer;
	}
	public String getCommnets() {
		return commnets;
	}
	public void setCommnets(String commnets) {
		this.commnets = commnets;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public String getResult() {
		return result;
	}
	public void setResult(String result) {
		this.result = result;
	}
	public Candidate getCandidate() {
		return candidate;
	}
	public void setCandidate(Candidate candidate) {
		this.candidate = candidate;
	}
	
}
